# simple-note-app
The objective of this JavaScript project is to create a notes application that uses local storage 
and allows for edits, among other things.  



